import java.util.Scanner;

public class grocerymain {
    public static void main(String[] args) {
        grocerycls grocery = new grocerycls("pricelist.txt");
        Scanner input = new Scanner(System.in);
        String codeInput;
        int qtyInput;   
        double total = 0;
        System.out.println("Enter 0 0 to quit and compute total.");
        System.out.println("------------------------------------");
        do {
            System.out.print("Enter Product Code and Quantity: ");
            codeInput = input.next();

            if (!codeInput.equals("0")) {
                qtyInput = input.nextInt();
                grocery.setCodeQty(codeInput, qtyInput);
                if (grocery.setPrice()){
                    double subtotal = grocery.subTotal();
                    System.out.print(qtyInput + " @ Php " + grocery.getPrice() + " = ");
                    System.out.println("Php " + subtotal);
                    total += subtotal;
                }
            }
        } while (!codeInput.equals("0"));

        System.out.println("TOTAL PRICE: Php " + total);
        System.out.println();
        System.out.println("------------------------------------");
    }
}